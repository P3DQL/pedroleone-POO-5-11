﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string recomendacion = "";
            if (radioButton1.Checked) recomendacion = "Sí";

            if (radioButton2.Checked) recomendacion = "No";

            label3.Text = "Opinión recibida: " + textBox1.Text + " - Recomendación: " + recomendacion;
        }
    }
}
