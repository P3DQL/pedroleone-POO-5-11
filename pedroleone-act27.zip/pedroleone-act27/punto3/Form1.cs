﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string destino = ""; 
            if (radioButton1.Checked) destino = "Playa";
            if (radioButton2.Checked) destino = "Montaña";
            if (radioButton3.Checked) destino = "Ciudad"; 
            label1.Text = destino + " - " + comboBox1.Text;
        }
    }
}
