﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto1
{
    /*Actividad 1: Registro de Usuario Simple
Problema:
Se desea crear un formulario para registrar usuarios en un sistema.
Requisitos:
● Mostrar etiquetas (Label) para &quot;Nombre&quot;, &quot;Apellido&quot; y &quot;Correo&quot;.
● Permitir que el usuario escriba los datos en TextBox.
● Incluir un botón &quot;Registrar&quot; que, al presionarlo, muestra en un Label un mensaje con
los datos ingresados concatenados.
    */
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
