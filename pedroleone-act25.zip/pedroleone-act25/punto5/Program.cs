namespace punto5
{
    /*5. Solicitar el ingreso de una clave de hasta 10 caracteres en un control de
    tipo TextBox (inicializar la propiedad MaxLength con el valor 10)
    Mostrar en un cuadro de mensajes la clave ingresada al presionar un
    botón.
    */
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}