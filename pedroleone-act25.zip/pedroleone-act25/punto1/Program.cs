namespace punto1
{
    /*1. Elaborar una interfaz gráfica que muestre una calculadora (utilizar
objetos de la clase Button y un objeto de la clase TextBox donde se
mostrarían los resultados y se cargarían los datos), tener en cuenta que
solo se debe implementar la interfaz y no la funcionalidad de una
calculadora.
    */
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}