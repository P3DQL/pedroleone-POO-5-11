﻿namespace punto1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button16 = new Button();
            button17 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(193, 191);
            button1.Name = "button1";
            button1.Size = new Size(44, 44);
            button1.TabIndex = 0;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(243, 191);
            button2.Name = "button2";
            button2.Size = new Size(44, 44);
            button2.TabIndex = 1;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(293, 191);
            button3.Name = "button3";
            button3.Size = new Size(44, 44);
            button3.TabIndex = 2;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.Location = new Point(193, 238);
            button16.Name = "button16";
            button16.Size = new Size(44, 44);
            button16.TabIndex = 15;
            button16.Text = "4";
            button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            button17.Location = new Point(243, 238);
            button17.Name = "button17";
            button17.Size = new Size(44, 44);
            button17.TabIndex = 16;
            button17.Text = "5";
            button17.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(243, 338);
            button4.Name = "button4";
            button4.Size = new Size(44, 44);
            button4.TabIndex = 17;
            button4.Text = "x";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(293, 338);
            button5.Name = "button5";
            button5.Size = new Size(44, 44);
            button5.TabIndex = 18;
            button5.Text = ":";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(343, 288);
            button6.Name = "button6";
            button6.Size = new Size(44, 94);
            button6.TabIndex = 19;
            button6.Text = "=";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(343, 238);
            button7.Name = "button7";
            button7.Size = new Size(44, 44);
            button7.TabIndex = 20;
            button7.Text = "-";
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(343, 191);
            button8.Name = "button8";
            button8.Size = new Size(44, 44);
            button8.TabIndex = 21;
            button8.Text = "+";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(193, 338);
            button9.Name = "button9";
            button9.Size = new Size(44, 44);
            button9.TabIndex = 22;
            button9.Text = "0";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(293, 288);
            button10.Name = "button10";
            button10.Size = new Size(44, 44);
            button10.TabIndex = 23;
            button10.Text = "9";
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(243, 288);
            button11.Name = "button11";
            button11.Size = new Size(44, 44);
            button11.TabIndex = 24;
            button11.Text = "8";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(193, 288);
            button12.Name = "button12";
            button12.Size = new Size(44, 44);
            button12.TabIndex = 25;
            button12.Text = "7";
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(293, 238);
            button13.Name = "button13";
            button13.Size = new Size(44, 44);
            button13.TabIndex = 26;
            button13.Text = "6";
            button13.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(193, 162);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(194, 23);
            textBox1.TabIndex = 27;
            textBox1.Text = "Ingrese un número";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox1);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button16;
        private Button button17;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private TextBox textBox1;
    }
}
