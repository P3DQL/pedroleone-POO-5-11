﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto2
{
    /*2. Permitir el ingreso de dos números en controles de tipo TextBox y mediante
dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
restarlos. Al presionar un botón mostrar en el título del Form el resultado de la
operación.*/
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
