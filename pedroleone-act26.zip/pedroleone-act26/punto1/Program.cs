﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto1
{
    /*1. Disponer tres objetos de la clase CheckBox con nombres de navegadores web.
    Cuando se presione un botón mostrar en el título del Form los programas
    seleccionados.
    */
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
