﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto3
{
    /*3. Solicitar el ingreso del nombre de una persona y seleccionar de un control
ComboBox un país. Al presionar un botón mostrar en la barra del título del
Form el nombre ingresado y el país seleccionado.
     */
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
